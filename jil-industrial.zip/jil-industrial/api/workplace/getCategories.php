<?php

include "../../data.php";

echo json_encode($LOCALPRODUCTCATEGORY);